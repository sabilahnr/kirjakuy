<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=h1, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="login.css">
</head>

<body class="index_signup">
    <img class="logo1" src="logo.png" alt="">
    <div class="kotak_login">
        <p class="tulisan_login">SIGN UP KIRJAKUY</h1>
            <br>
        <form action="" method="post">
            <table>
                <div class="label_1">
                    <tr>
                        <td>Username</td>
                        <td><input type="text" name="username" id="username"></td>
                    </tr>
                    <tr>
                        <td>Password</td>
                        <td><input type="password" name="password" id="password"></td>
                    </tr>
                    <tr>
                        <td>Konfirmasi Password</td>
                        <td><input type="password" name="password2" id="password2"></td>
                    </tr>
                </div>

                <tr>
                    <td></td>
                    <center>
                        <td><button type="submit" name="signup" class="tombol_login">Sign Up</button></td>
                        <td><button type="submit" name="kembali" class="tombol_login"><a href="index.php">kembali</a></button></td>
                    </center>
                </tr>

            </table>
        </form>
    </div>

</body>

</html>