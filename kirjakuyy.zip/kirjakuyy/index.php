<?php

require 'functions.php';

$rows = query("SELECT * FROM db_mahasiswa");

?>


<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=tab, initial-scale=1.0">
    <title>Document</title>
</head>


<body>
    <h1>= Data Mahasiswa =</h1>
    <a href="tambah.php"> Tambah Data </a>
    <br>
    <br>
    <table border="1" cellpadding=10 cellspancing=0>
        <thead>
            <th>No</th>
            <th>NIM</th>
            <th>Nama</th>
            <th>Email</th>
            <th>Jurusan</th>
            <th>Action</th>
        </thead>

        <tbody>
            <?php foreach ($rows as $row) : ?>
                <tr>
                    <td><?php echo $row["id"] ?></td>
                    <td><?php echo $row["nim"] ?></td>
                    <td><?php echo $row["nama"] ?></td>
                    <td><?php echo $row["email"] ?></td>
                    <td><?php echo $row["jurusan"] ?></td>
                    <td>
                        <a href="ubah.php?id= <?php echo $row["id"] ?>">ubah |</a>
                        <a href="hapus.php?id= <?php echo $row["id"] ?>" onclick="return confirm('Apakah kamu yakin akan menghapus data ini?')">hapus</a>
                    </td>
                </tr>
            <?php endforeach; ?>
        </tbody>

    </table>

</body>

</html>

