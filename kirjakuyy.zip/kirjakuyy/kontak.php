<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="Syasyi.css">
</head>

<body class="Halaman_Utama">
    <div class="Utama">
        <a class="Home" href="HalUtama.php">Home</a>
        <a class="Tentang" href="tentang.php">Tentang</a>
        <a class="Kontak" href="kontak.php">Kontak</a>
        <a class="login" href="">| Login</a>
        <a class="Sign_Up" href="">Sign in</a>
    </div>
    <div id="kotak_kontak">
        <svg class="kotak1">
            <rect id="kotak1" rx="0" ry="0" x="0" y="0" width="1328" height="155">
            </rect>
        </svg>
        <div id="Kontak"><b>Kontak</b></div>
    </div>
    <div id="nomer">
        <span>
            081231503118(Bella)
            <br />
            082225134727(Sabila)
            <br />
            081225967157(Syi'ta)
        </span>
    </div>

</body>

</html>