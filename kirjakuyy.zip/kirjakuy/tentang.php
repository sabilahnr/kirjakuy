<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="Syasyi.css">
</head>

<body class="b_tentang">
    <div class="Utama">
        <a class="Home" href="HalUtama.php">Home</a>
        <a class="Tentang" href="tentang.php">Tentang</a>
        <a class="Kontak" href="">Kontak |</a>
        <a class="login" href=""> Login</a>
        <a class="Sign_Up" href="">Sign in</a>
    </div>
    <h1 class="judul">Tentang Kami</h1>
    <svg class="Rectangle_9">
        <rect id="Rectangle_9" rx="0" ry="0" x="0" y="0" width="1628" height="675">
        </rect>
    </svg>
    <div class="isi">
        Aplikasi ini seperti yang kita ketahui jasa kurir pengiriman paket <br />
        adalah produk jasa yang memberikan jasa berupa pengiriman dokumen <br />
        maupun barang hingga sampai kepada tujuan.<br />
        Jasa kurir pengiriman sudah menjadi kebutuhan dalam kehidupan <br />
        aktivitas masyarakat seperti aktivitas bisnis maupun aktifitas pribadi. <br />
        Perkembangan mobilitas masyarakat dan<br />
        teknologi juga semakin meningkatkan pelayanan dari jasa ini dengan <br />
        mulai bermunculannya layanan ekspres atau kilat, dimana barang yang <br />
        dikirim dapat sampai dengan waktu yang relatif cepat. <br />
        <br />
        <br />
    </div>
    <br>

</body>

</html>