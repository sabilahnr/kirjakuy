<!DOCTYPE html>
<html>
<head>
	<title>Membuat Desain Form Login Dengan CSS - www.malasngoding.com</title>
	<link rel="stylesheet" href="login.css">
</head>
<body>
 
<img class="logo1" src="logo.png" alt="">
    <div class="kotak_login">
	<p class="tulisan_login">LOGIN KIRJAKUY</p>
 
	<form>
		<label>Username</label>
		<input type="text" name="username" class="form_login" placeholder="Username atau email ..">
 
		<label>Password</label>
		<input type="text" name="password" class="form_login" placeholder="Password ..">
 
		<input type="submit" class="tombol_login" value="LOGIN">
 
		<br/>
		<br/>
		<center>
			<a class="link" href="index.php">kembali</a>
		</center>
	</form>
	
</div>


</body>
</html>