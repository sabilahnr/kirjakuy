<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css">
    <title>KirjaKuy</title>
</head>
<body>
    <div class="navigasi">
        <a class="Home" href="HalUtama.php">Home</a>
        <a class="Tentang" href="tentang.php">Tentang</a>
        <a class="Kontak" href="kontak.php">Kontak</a>
        <a><button class="login" href="login.php">Login</button></a>
        <a><button class="Sign_up" href="">Sign Up</button></a>
    </div>
    <h1 class="opening"> SELAMAT DATANG !!<br> KirjaKuy </h1>
    <button class="Sign_up2">Sign Up</button>
    <img class="logo1" src="logo.png" alt="logo">
</body>
</html>

