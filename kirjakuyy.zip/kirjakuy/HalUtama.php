<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="Syasyi.css">
</head>

<body class="Halaman_Utama">
    <div class="Utama">
        <a class="Home" href="HalUtama.php">Home</a>
        <a class="Tentang" href="tentang.php">Tentang</a>
        <a class="Kontak" href="kontak.php">Kontak</a>
        <a class="login" href="login.php">| Login</a>
        <a class="Sign_Up" href="">Sign in</a>
    </div>
    <h1 class="SELAMAT_DATANG__KirjaKuy_"> SELAMAT DATANG !!<br>
        KirjaKuy</br>
    </h1>
    <div id="Group_1">
        <div>
            <svg class="kotak_signup">
                <rect rx="0" ry="0" x="0" y="0" width="300" height="100">
                </rect>
            </svg>
        </div>
        <div>
        <a class="Sign_Up2"  href="login.php">Sign Up</a>

        </div>
    </div>
    <img class="logo1" src="logo.png" alt="">


</body>

</html>